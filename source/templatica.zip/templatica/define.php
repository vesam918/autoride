<?php

/******************************************************************************/
/******************************************************************************/

define('PLUGIN_TEMPLATICA_VERSION','2.8');

define('PLUGIN_TEMPLATICA_CONTEXT','templatica');
define('PLUGIN_TEMPLATICA_OPTION_PREFIX','templatica');

define('PLUGIN_TEMPLATICA_PATH',plugin_dir_path(__FILE__));
define('PLUGIN_TEMPLATICA_PATH_VC',PLUGIN_TEMPLATICA_PATH.'vc/');
define('PLUGIN_TEMPLATICA_PATH_VIEW',PLUGIN_TEMPLATICA_PATH.'view/');
define('PLUGIN_TEMPLATICA_PATH_CLASS',PLUGIN_TEMPLATICA_PATH.'class/');

define('PLUGIN_TEMPLATICA_URL',plugins_url('templatica').'/');
define('PLUGIN_TEMPLATICA_URL_STYLE',PLUGIN_TEMPLATICA_URL.'style/');
define('PLUGIN_TEMPLATICA_URL_SCRIPT',PLUGIN_TEMPLATICA_URL.'script/');

/******************************************************************************/
/******************************************************************************/