<?php

/******************************************************************************/
/******************************************************************************/

require_once(plugin_dir_path(__FILE__).'define.php');

require_once(PLUGIN_TEMPLATICA_PATH_CLASS.'Templatica.File.class.php');
require_once(PLUGIN_TEMPLATICA_PATH_CLASS.'Templatica.Include.class.php');

TemplaticaInclude::includeFileFromDir(PLUGIN_TEMPLATICA_PATH_CLASS);

/******************************************************************************/
/******************************************************************************/