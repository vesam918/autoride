<?php

/******************************************************************************/
/******************************************************************************/

require_once(plugin_dir_path(__FILE__).'define.php');

require_once(PLUGIN_WIDGET_AREA_CLASS_PATH.'WA.File.class.php');
require_once(PLUGIN_WIDGET_AREA_CLASS_PATH.'WA.Include.class.php');

WAInclude::includeFileFromDir(PLUGIN_WIDGET_AREA_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/