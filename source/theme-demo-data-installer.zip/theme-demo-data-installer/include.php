<?php

/******************************************************************************/
/******************************************************************************/

require_once(plugin_dir_path(__FILE__).'define.php');

/******************************************************************************/

require_once(PLUGIN_THEME_INSTALLER_CLASS_PATH.'TI.File.class.php');
require_once(PLUGIN_THEME_INSTALLER_CLASS_PATH.'TI.Include.class.php');

TIInclude::includeFileFromDir(PLUGIN_THEME_INSTALLER_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/