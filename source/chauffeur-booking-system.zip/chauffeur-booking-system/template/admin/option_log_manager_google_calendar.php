<?php
		$LogManager=new CHBSLogManager();
		echo $LogManager->show('google_calendar');