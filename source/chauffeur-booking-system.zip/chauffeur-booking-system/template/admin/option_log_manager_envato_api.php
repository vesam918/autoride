<?php
		$LogManager=new CHBSLogManager();
		echo $LogManager->show('envato_api');