<?php

/******************************************************************************/
/******************************************************************************/

define('PLUGIN_ARC_VERSION','2.1');

define('PLUGIN_ARC_DOMAIN','autoride-core');

define('PLUGIN_ARC_URL',plugins_url('autoride-core').'/');
define('PLUGIN_ARC_PATH',plugin_dir_path(__FILE__));

define('PLUGIN_ARC_CLASS_PATH',PLUGIN_ARC_PATH.'class/');
define('PLUGIN_ARC_STYLE_PATH',PLUGIN_ARC_PATH.'style/');
define('PLUGIN_ARC_SCRIPT_PATH',PLUGIN_ARC_PATH.'script/');
define('PLUGIN_ARC_TEMPLATE_PATH',PLUGIN_ARC_PATH.'template/');

define('PLUGIN_ARC_VC_PATH',PLUGIN_ARC_PATH.'vc/');
define('PLUGIN_ARC_VC_ELEMENT_PATH',PLUGIN_ARC_VC_PATH.'element/');

define('PLUGIN_ARC_CLASS_URL',PLUGIN_ARC_URL.'class/');
define('PLUGIN_ARC_STYLE_URL',PLUGIN_ARC_URL.'style/');
define('PLUGIN_ARC_SCRIPT_URL',PLUGIN_ARC_URL.'script/');

define('PLUGIN_ARC_THEME_CLASS_PATH',get_template_directory().'/class/');

/******************************************************************************/
/******************************************************************************/