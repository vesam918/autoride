<?php

/******************************************************************************/
/******************************************************************************/

require_once('define.php');

/******************************************************************************/

require_once(PLUGIN_ARC_THEME_CLASS_PATH.'Theme.File.class.php');
require_once(PLUGIN_ARC_THEME_CLASS_PATH.'Theme.Include.class.php');

require_once(PLUGIN_ARC_CLASS_PATH.'ARC.Widget.class.php');

Autoride_ThemeInclude::includeFileFromDir(PLUGIN_ARC_CLASS_PATH);

/******************************************************************************/
/******************************************************************************/